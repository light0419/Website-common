/**
 * jQuery Plugins imgFloat v1011
 * 
 * @使用说明：
 * @speed 元素移动速度
 * @xPos 元素一开始左距离
 * @yPos 元素一开始上距离
 */
(function($) {
	jQuery.fn.dynamicFloat = function(options) {
		// 对象引用
		var self = this;
		// x轴方向是否超出边界标志
		var xFlag = 0;
		// y轴方向是否超出边界标志
		var yFlag = 0;
		// 每次移动距离
		var i = 1;
		// 默认参数
		var settings = {
			speed : 10,
			xPos : 0,
			yPos : 0
		};

		jQuery.extend(settings, options);
		// 距离顶部距离
		var selfTop = settings.xPos;
		// 距离左侧距离
		var selfLeft = settings.yPos;
		// 设置对象css属性
		self.css({
			position : "fixed",
			cursor : "auto"
		});

		// 位置位置动态浮动函数
		function dynamicMove() {
			// 对象x轴方向距离左侧的的最大值
			var winWidth = $(window).width() - self.width();
			// 对象y轴方向距离顶部的最大值
			var winHeight = $(window).height() - self.height();
			// x轴方向正向移动
			if (xFlag == 0) {
				selfLeft += i;
				self.css({
					left : selfLeft
				});
				if (selfLeft >= winWidth) {
					selfLeft = winWidth;
					xFlag = 1;
				}
			}
			// x轴负向移动
			if (xFlag == 1) {
				selfLeft -= i;
				self.css({
					left : selfLeft
				});
				if (selfLeft <= 0)
					xFlag = 0;
			}
			// y轴方向正向移动
			if (yFlag == 0) {
				selfTop += i;
				self.css({
					top : selfTop
				});
				if (selfTop >= winHeight) {
					selfTop = winHeight;
					yFlag = 1;
				}
			}
			// y轴方向负向移动
			if (yFlag == 1) {
				selfTop -= i;
				self.css({
					top : selfTop
				});
				if (selfTop <= 0)
					yFlag = 0;
			}
		}

		// 定时执行移动函数
		var floatHover = setInterval(dynamicMove, settings.speed);

		// 切换对象的移动与停止
		self.hover(function() {
			clearInterval(floatHover);
		}, function() {
			floatHover = setInterval(dynamicMove, settings.speed);
		});
	};
})(jQuery);